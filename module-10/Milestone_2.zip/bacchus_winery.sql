/*
    Title: db_init_2025.sql
    Author: Jose Flores, Laura Makokha
    Date: 1 May 2025
    Description: Bacchus Winery database initialization script.
*/

-- Step 1: Drop the existing database user (if it exists)
DROP USER IF EXISTS 'bacchus_user'@'localhost';

-- Step 2: Create bacchus_user and grant them all privileges to the bacchus_winery database
CREATE USER 'bacchus_user'@'localhost' IDENTIFIED WITH mysql_native_password BY 'winerypassword';

-- Grant all privileges to the bacchus_winery database to user bacchus_user on localhost
GRANT ALL PRIVILEGES ON bacchus_winery.* TO 'bacchus_user'@'localhost';

-- Step 3: Drop the existing database (if it exists)
DROP DATABASE IF EXISTS bacchus_winery;

-- Step 4: Create the bacchus_winery database
CREATE DATABASE bacchus_winery;

-- Step 5: Use the created database
USE bacchus_winery;

-- Step 6: Create the Tables

-- Wine Table
CREATE TABLE IF NOT EXISTS Wine (
    Wine_ID INT AUTO_INCREMENT PRIMARY KEY,
    Wine_Name VARCHAR(255) NOT NULL,
    Quantity_in_Inventory INT NOT NULL,
    Type VARCHAR(255) NOT NULL,
    Price DECIMAL(10, 2) NOT NULL
);

-- Suppliers Table
CREATE TABLE IF NOT EXISTS Suppliers (
    Supplier_ID INT AUTO_INCREMENT PRIMARY KEY,
    Supplier_Name VARCHAR(255) NOT NULL,
    Contact_Info VARCHAR(255) NOT NULL,
    Supply_Type VARCHAR(255) NOT NULL
);

-- Supplies Table
CREATE TABLE IF NOT EXISTS Supplies (
    Supply_ID INT AUTO_INCREMENT PRIMARY KEY,
    Supply_Name VARCHAR(255) NOT NULL,
    Quantity_in_Inventory INT NOT NULL,
    Supplier_ID INT,
    FOREIGN KEY (Supplier_ID) REFERENCES Suppliers(Supplier_ID)
);

-- Supply Deliveries Table
CREATE TABLE IF NOT EXISTS Supply_Deliveries (
    Delivery_ID INT AUTO_INCREMENT PRIMARY KEY,
    Supply_ID INT,
    Supplier_ID INT,
    Planned_Delivery_Date DATE,
    Actual_Delivery_Date DATE,
    Quantity_Received INT,
    FOREIGN KEY (Supply_ID) REFERENCES Supplies(Supply_ID),
    FOREIGN KEY (Supplier_ID) REFERENCES Suppliers(Supplier_ID)
);

-- Distributors Table
CREATE TABLE IF NOT EXISTS Distributors (
    Distributor_ID INT AUTO_INCREMENT PRIMARY KEY,
    Distributor_Name VARCHAR(255) NOT NULL,
    Contact_Info VARCHAR(255) NOT NULL,
    Distributor_Location VARCHAR(255) NOT NULL
);

-- Wine Distribution Table
CREATE TABLE IF NOT EXISTS Wine_Distribution (
    Distributor_ID INT,
    Wine_ID INT,
    Quantity_Sold INT NOT NULL,
    Sales_Date DATE NOT NULL,
    PRIMARY KEY (Distributor_ID, Wine_ID),
    FOREIGN KEY (Distributor_ID) REFERENCES Distributors(Distributor_ID),
    FOREIGN KEY (Wine_ID) REFERENCES Wine(Wine_ID)
);

-- Employee Table
CREATE TABLE IF NOT EXISTS Employee (
    Employee_ID INT AUTO_INCREMENT PRIMARY KEY,
    Employee_Name VARCHAR(255) NOT NULL,
    Department VARCHAR(255) NOT NULL,
    Contact_Info VARCHAR(255) NOT NULL
);

-- Employee Hours Table
CREATE TABLE IF NOT EXISTS Employee_Hours (
    Employee_ID INT,
    Quarter VARCHAR(10) NOT NULL,
    Hours_Worked INT NOT NULL,
    PRIMARY KEY (Employee_ID, Quarter),
    FOREIGN KEY (Employee_ID) REFERENCES Employee(Employee_ID)
);

-- Orders Table
CREATE TABLE IF NOT EXISTS Orders (
    Order_ID INT AUTO_INCREMENT PRIMARY KEY,
    Distributor_ID INT,
    Wine_ID INT,
    Order_Date DATE NOT NULL,
    Order_Status VARCHAR(255) NOT NULL,
    FOREIGN KEY (Distributor_ID) REFERENCES Distributors(Distributor_ID),
    FOREIGN KEY (Wine_ID) REFERENCES Wine(Wine_ID)
);

-- Step 7: Insert Sample Data into the Tables

-- Insert Wine Sample Data
INSERT INTO Wine (Wine_Name, Quantity_in_Inventory, Type, Price) VALUES
('Merlot', 100, 'Red', 20.00),
('Cabernet', 150, 'Red', 22.00),
('Chablis', 200, 'White', 18.00),
('Chardonnay', 120, 'White', 19.00);

-- Insert Supplier Sample Data
INSERT INTO Suppliers (Supplier_Name, Contact_Info, Supply_Type) VALUES
('Bottle Co.', 'contact@bottleco.com', 'Bottles'),
('Cork Supply', 'support@cork.com', 'Corks'),
('Label Works', 'info@labelworks.com', 'Labels'),
('VatsAndTubing', 'support@vatsandtubing.com', 'Vats');

-- Insert Supplies Sample Data
INSERT INTO Supplies (Supply_Name, Quantity_in_Inventory, Supplier_ID) VALUES
('Bottles', 1000, 1),
('Corks', 1500, 2),
('Labels', 2000, 3),
('Vats', 50, 4);

-- Insert Supply Deliveries Sample Data
INSERT INTO Supply_Deliveries (Supply_ID, Supplier_ID, Planned_Delivery_Date, Actual_Delivery_Date, Quantity_Received) VALUES
(1, 1, '2025-04-01', '2025-04-01', 500),
(2, 2, '2025-04-01', '2025-04-02', 600),
(3, 3, '2025-04-01', '2025-04-01', 700),
(4, 4, '2025-04-01', '2025-04-03', 40);

-- Insert Distributor Sample Data
INSERT INTO Distributors (Distributor_Name, Contact_Info, Distributor_Location) VALUES
('Wine Distributors Inc.', 'info@winedistributors.com', 'California'),
('Global Wines', 'sales@globalwines.com', 'New York'),
('Vino Partners', 'contact@vinopartners.com', 'Texas'),
('Best Wines', 'contact@bestwines.com', 'Florida');

-- Insert Wine Distribution Sample Data
INSERT INTO Wine_Distribution (Distributor_ID, Wine_ID, Quantity_Sold, Sales_Date) VALUES
(1, 1, 50, '2025-04-05'),
(2, 2, 60, '2025-04-10'),
(3, 3, 70, '2025-04-12'),
(4, 4, 40, '2025-04-15');

-- Insert Employee Sample Data
INSERT INTO Employee (Employee_Name, Department, Contact_Info) VALUES
('Janet Collins', 'Finance', 'janet@bacchus.com'),
('Roz Murphy', 'Marketing', 'roz@bacchus.com'),
('Henry Doyle', 'Production', 'henry@bacchus.com'),
('Maria Costanza', 'Distribution', 'maria@bacchus.com'),
('John Doe', 'Production', 'john@bacchus.com');

-- Insert Employee Hours Sample Data
INSERT INTO Employee_Hours (Employee_ID, Quarter, Hours_Worked) VALUES
(1, 'Q1', 160),
(2, 'Q1', 150),
(3, 'Q1', 170),
(4, 'Q1', 180),
(5, 'Q1', 165);

-- Insert Orders Sample Data
INSERT INTO Orders (Distributor_ID, Wine_ID, Order_Date, Order_Status) VALUES
(1, 1, '2025-04-01', 'Shipped'),
(2, 2, '2025-04-05', 'Ordered'),
(3, 3, '2025-04-10', 'Delivered'),
(4, 4, '2025-04-15', 'Ordered');

-- Step 8: Show Tables (Optional, to confirm everything is set up)
SHOW TABLES;