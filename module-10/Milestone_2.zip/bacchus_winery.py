# Name: Jose Flores, Laura Makokha
# Date: 5/2/2025
# Assignment_10: Bacchus Winery Project Milestone

import mysql.connector
from mysql.connector import errorcode
import dotenv
from dotenv import dotenv_values

# Load secrets from the .env file
secrets = dotenv_values(".env")

# Database config object
config = {
    "user": secrets["USER"],          # 'root' from .env
    "password": secrets["PASSWORD"],  # 'mysecretpassword' from .env
    "host": secrets["HOST"],          # 'localhost' from .env
    "database": secrets["DATABASE"],  # 'bacchus_winery' from .env
    "raise_on_warnings": True          # Optional: Better error handling
}

def connect_to_database():
    """Establishes a connection to the MySQL database."""
    try:
        db = mysql.connector.connect(**config)  # Connect using config
        print(f"Connected to {secrets['DATABASE']} as {secrets['USER']} on {secrets['HOST']}")
        return db
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
            print("The supplied username or password are invalid.")
        elif err.errno == errorcode.ER_BAD_DB_ERROR:
            print("The specified database does not exist.")
        else:
            print(err)
        return None

def display_table_data(db):
    """Retrieves and displays data from all tables in the bacchus_winery database."""
    cursor = db.cursor(dictionary=True)  # Use dictionary cursor to fetch results as dictionaries

    # List of tables to display
    tables = [
        "Wine", "Suppliers", "Supplies", "Supply_Deliveries", 
        "Distributors", "Wine_Distribution", "Employee", 
        "Employee_Hours", "Orders"
    ]
    
    for table in tables:
        print(f"\n\nData from {table} table:")
        cursor.execute(f"SELECT * FROM {table};")
        rows = cursor.fetchall()
        
        if rows:
            for row in rows:
                print(row)
        else:
            print(f"No data found in {table} table.")
    
    cursor.close()

def main():
    """Main function to execute the script."""
    db = connect_to_database()
    
    if db:
        display_table_data(db)
        db.close()  # Close the database connection

if __name__ == "__main__":
    main()
